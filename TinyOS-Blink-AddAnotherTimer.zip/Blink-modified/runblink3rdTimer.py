#!/usr/bin/python
from TOSSIM import *
import sys
t = Tossim([])
r = t.radio()
t.addChannel("BlinkC", sys.stdout)
m = t.getNode(1)
m.bootAtTime(100)
while (m.isOn() == 0):
    t.runNextEvent()
#modified to run 2000 times instead of 100 for Exercise
for i in range(0, 2000): 
    t.runNextEvent()
